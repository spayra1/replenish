# API Documentation

This file should contain documentation introducing your API to **end-users**.
It will display on your service's [Standard Library](https://stdlib.com/)
documentation page if you choose to publish it.

Usage examples and additional information around calling your API belong here.