# README
[<img src="https://code.stdlib.com/button/button.svg" height="32">](https://code.stdlib.com/)

This is the README for you API. It is intended to guide other developers on
**internal implementation** of your code. It **will not** be displayed in your
[Standard Library](https://stdlib.com/) documentation.

You can include an **Code on Standard Library** button for GitHub, as displayed above.